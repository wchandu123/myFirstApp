<?php

Yii::import('application.models._base.BaseBOOKINGMODEL');

class BOOKINGMODEL extends BaseBOOKINGMODEL
{
	public static function model($className=__CLASS__) {
		return parent::model($className);
	}
}