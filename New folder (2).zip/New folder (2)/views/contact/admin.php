<?php

$this->breadcrumbs = array(
	$model->label(2) => array('index'),
	Yii::t('app', 'Manage'),
);



Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$.fn.yiiGridView.update('contact-grid', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<h1><?php echo Yii::t('app', 'Manage') . ' ' . GxHtml::encode($model->label(2)); ?></h1>



<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id' => 'contact-grid',
	'dataProvider' => $model->search(),
	'filter' => $model,
	'columns' => array(
		'id',
		'FIRST_NAME',
		'LAST_NAME',
		'EMAIL_ID',
		'MOBILE_NUMBER',
		'COMMENTS',
		/*
		'CAPTCHA',
		*/
		array(
			'class' => 'CButtonColumn',
			'template'=>'{view}{delete}',
		),
	),
)); ?>