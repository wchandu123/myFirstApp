<?php

class SiteController extends Controller {

    /**
     * Declares class-based actions.
     */
    public function actions() {
        return array(
            // captcha action renders the CAPTCHA image displayed on the contact page
            'captcha' => array(
                'class' => 'CCaptchaAction',
                'backColor' => 0xFFFFFF,
            ),
            // page action renders "static" pages stored under 'protected/views/site/pages'
            // They can be accessed via: index.php?r=site/page&view=FileName
            'page' => array(
                'class' => 'CViewAction',
            ),
        );
    }

    /**
     * This is the default 'index' action that is invoked
     * when an action is not explicitly requested by users.
     */
    public function actionIndex() {
        // renders the view file 'protected/views/site/index.php'
        // using the default layout 'protected/views/layouts/main.php'
        $this->render('index');
    }

    /**
     * This is the action to handle external exceptions.
     */
    public function actionError() {
        if ($error = Yii::app()->errorHandler->error) {
            if (Yii::app()->request->isAjaxRequest)
                echo $error['message'];
            else
                $this->render('error', $error);
        }
    }

    /**
     * Displays the contact page
     */
    public function actionContact() {
        $model = new CONTACT; 
        if (isset($_POST['CONTACT'])) { 
			$model->attributes=$_POST['CONTACT'];
			$model->created = new CDbExpression('NOW()');
			if ($model->validate()) {
				if($model->save()){
					$admin_body = $this->adminTemplate($_POST['CONTACT']);
					$user_body = $this->userTemplate($_POST['CONTACT']);
					$to_user = $_POST['CONTACT']['EMAIL_ID'];
					$to_admin = "chandu.dhaundiyal@gmail.com";
					$subject = "Contact Form Details";
					$headers = "From: eventmanagement@event.com";
					//mail($to_user,$subject,$user_body,$headers);
					//mail($to_admin,$subject,$admin_body,$headers);
					Yii::app()->user->setFlash('contact', 'Thank you for contacting us. We will respond to you as soon as possible.');
				}
			}
        }
        $this->render('contact', array('model' => $model));
    }
	
	protected function adminTemplate($user_data){
		
		$html = '';
		$html .= '<table><tr><td>Dear Admins,</td></tr>
		<tr><td>The following user has submitted content from the Contact Us Form</td></tr></table><br>';
		$html .='<table>
					<tr>
						<td>First Name :</td>
						<td>'.$user_data['FIRST_NAME'].'</td>
					</tr>
					<tr>
						<td>Last Name :</td>
						<td>'.$user_data['LAST_NAME'].'</td>
					</tr>
					<tr>
						<td>Email :</td>
						<td>'.$user_data['EMAIL_ID'].'</td>
					</tr>
					<tr>
						<td>Mobile Number :</td>
						<td>'.$user_data['MOBILE_NUMBER'].'</td>
					</tr>
					<tr>
						<td>Comments :</td>
						<td>'.$user_data['COMMENTS'].'</td>
					</tr>
				</table>';
				return $html;
		
	}

	protected function userTemplate($user_data){
		$name = $user_data['FIRST_NAME']." ".$user_data['LAST_NAME'];
		$html = '';
		$html .= '<table><tr><td>Dear '.$name.',</td></tr>
		<tr><td>Thank you for sharing your valuable feedback, below are the details you have submitted</td></tr></table></br>';
		$html .='<table>
					<tr>
						<td>First Name :</td>
						<td>'.$user_data['FIRST_NAME'].'</td>
					</tr>
					<tr>
						<td>Last Name :</td>
						<td>'.$user_data['LAST_NAME'].'</td>
					</tr>
					<tr>
						<td>Email :</td>
						<td>'.$user_data['EMAIL_ID'].'</td>
					</tr>
					<tr>
						<td>Mobile Number :</td>
						<td>'.$user_data['MOBILE_NUMBER'].'</td>
					</tr>
					<tr>
						<td>Comments :</td>
						<td>'.$user_data['COMMENTS'].'</td>
					</tr>
				</table></br></br>';
		$html .='<table><tr><td>Thanks</td></tr>
						<tr><td>Admin</td></tr></table>';
		return $html;
		
	}
    /**
     * Displays the login page
     */
    public function actionLogin() {
        $model = new LoginForm;

        // if it is ajax validation request
        if (isset($_POST['ajax']) && $_POST['ajax'] === 'login-form') {
            echo CActiveForm::validate($model);
            Yii::app()->end();
        }

        // collect user input data
        if (isset($_POST['LoginForm'])) {
            $model->attributes = $_POST['LoginForm'];
            // validate user input and redirect to the previous page if valid
            if ($model->validate() && $model->login())
                $this->redirect(Yii::app()->user->returnUrl);
        }
        // display the login form
        $this->render('login', array('model' => $model));
    }

    /**
     * Logs out the current user and redirect to homepage.
     */
    public function actionLogout() {
        Yii::app()->user->logout();
        $this->redirect(Yii::app()->homeUrl);
    }

    
    public function actionBooking(){
       $username = "Ruchi";
        if(isset($_POST['event_list'])){
          $event_list = isset($_POST['event_list'])?$_POST['event_list']:"";
          $data = BOOKINGMODEL::model()->find(array('condition' => 'USER_ID = :USER_ID and EVENT_ID = :EVENT_ID', 'params' => array(':USER_ID'=>$username, ':EVENT_ID'=>$event_list)));
          
          if(empty($data)){
              $model = new BOOKINGMODEL;
              $model->EVENT_ID = $event_list;
              $model->USER_ID = $username;
              $model->CREATED = new CDbExpression('NOW()');
              if($model->save()){
                  Yii::app()->user->setFlash('booking', 'Thank you for Booking Event. Your seat has been booked.');
              }
          } else {
               Yii::app()->user->setFlash('alreadyExist', 'You have already booked this event.');
          }
          
        }

        $this->render('booking');
    }
}