<?php if(Yii::app()->user->hasFlash('booking')){ ?>

<div class="flash-success">
	<?php echo Yii::app()->user->getFlash('booking'); ?>
</div>
<?php } else if(Yii::app()->user->hasFlash('alreadyExist')) { ?>
<div class="flash-success">
	<?php echo Yii::app()->user->getFlash('alreadyExist'); ?>
</div>
<?php } else { ?>
<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'booking-form',
	'enableClientValidation'=>true,
	'clientOptions'=>array(
		'validateOnSubmit'=>true,
	),
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>



	<div class="row">
                
		<?php echo CHtml::label(Yii::t('demo', 'Select Event: '), 'event'); ?>
                <?php echo CHtml::dropDownList('event_list','', array('1'=>'Event1', '2'=>'Event2'),array('empty'=>'Select Option'));
 ?>
		
	</div>


	


	<div class="row buttons">
		<?php echo CHtml::submitButton('Submit'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->
<?php }?>