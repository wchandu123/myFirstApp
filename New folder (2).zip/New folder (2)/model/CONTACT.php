<?php

Yii::import('application.models._base.BaseCONTACT');

class CONTACT extends BaseCONTACT
{
	public static function model($className=__CLASS__) {
		return parent::model($className);
	}
}