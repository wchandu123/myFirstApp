<?php

Yii::import('application.models._base.BaseROLE');

class ROLE extends BaseROLE
{
	public static function model($className=__CLASS__) {
		return parent::model($className);
	}
}